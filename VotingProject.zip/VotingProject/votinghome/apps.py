from django.apps import AppConfig


class VotinghomeConfig(AppConfig):
    name = 'votinghome'
