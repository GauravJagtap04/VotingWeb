from django.apps import AppConfig


class VotingresultConfig(AppConfig):
    name = 'votingresult'
