from django.apps import AppConfig


class VotingcontactConfig(AppConfig):
    name = 'votingcontact'
