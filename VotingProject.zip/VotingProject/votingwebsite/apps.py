from django.apps import AppConfig


class VotingwebsiteConfig(AppConfig):
    name = 'votingwebsite'
